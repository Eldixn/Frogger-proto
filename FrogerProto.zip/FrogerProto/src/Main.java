import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class FroggerGame extends JFrame implements KeyListener {

    private static final int WIDTH = 800;
    private static final int HEIGHT = 600;
    private Frog frog;

    public FroggerGame() {
        setTitle("Frogger Game");
        setSize(WIDTH, HEIGHT);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        frog = new Frog(WIDTH / 2, HEIGHT - 50);

        addKeyListener(this);
        setFocusable(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            FroggerGame game = new FroggerGame();
            game.setVisible(true);
        });
    }

    @Override
    public void keyTyped(KeyEvent e) {}

    @Override
    public void keyPressed(KeyEvent e) {
        int key = e.getKeyCode();

        switch (key) {
            case KeyEvent.VK_UP:
                frog.moveUp();
                break;
            case KeyEvent.VK_DOWN:
                frog.moveDown();
                break;
            case KeyEvent.VK_LEFT:
                frog.moveLeft();
                break;
            case KeyEvent.VK_RIGHT:
                frog.moveRight();
                break;
        }
        repaint();
    }

    @Override
    public void keyReleased(KeyEvent e) {}

    @Override
    public void paint(Graphics g) {
        super.paint(g);
        frog.draw(g);
    }

    private class Frog {
        private int x, y;

        public Frog(int x, int y) {
            this.x = x;
            this.y = y;
        }

        public void moveUp() {
            if (y > 0) {
                y -= 20;
            }
        }

        public void moveDown() {
            if (y < HEIGHT - 50) {
                y += 20;
            }
        }

        public void moveLeft() {
            if (x > 0) {
                x -= 20;
            }
        }

        public void moveRight() {
            if (x < WIDTH - 20) {
                x += 20;
            }
        }

        public void draw(Graphics g) {
            g.setColor(Color.GREEN);
            g.fillRect(x, y, 20, 20);
        }
    }
}
